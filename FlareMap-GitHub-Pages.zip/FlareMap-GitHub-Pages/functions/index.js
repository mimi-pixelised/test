"use strict";

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineString } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();

const ADMIN_EMAILS = defineString("FLAREMAP_ADMIN_EMAILS");
const TOPIC = "flaremap-all-subscribers";
const REGION = "asia-southeast1";
const options = { region: REGION, timeoutSeconds: 60 };

function isAdmin(request) {
  const user = request.auth?.token;
  if (!user || user.email_verified !== true || typeof user.email !== "string") return false;
  const allowlist = ADMIN_EMAILS.value().split(",").map(email => email.trim().toLowerCase()).filter(Boolean);
  return allowlist.includes(user.email.toLowerCase());
}

function requireAdmin(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "An administrator must sign in first.");
  if (!isAdmin(request)) throw new HttpsError("permission-denied", "Verified administrator access required.");
}

function validateToken(token) {
  if (typeof token !== "string" || token.length < 20 || token.length > 4096 || /\s/.test(token)) {
    throw new HttpsError("invalid-argument", "Invalid Firebase Messaging registration token.");
  }
  return token;
}

// Anyone who explicitly opts in on their own device can receive notifications.
// No admin credentials are necessary for an ordinary subscriber.
exports.registerFlareMapDevice = onCall(options, async request => {
  const token = validateToken(request.data?.token);
  try {
    const result = await admin.messaging().subscribeToTopic(token, TOPIC);
    if (result.failureCount) throw new Error("Could not subscribe this token to notifications.");
    return { subscribed: true };
  } catch (error) {
    console.error("FCM topic subscription failed", error);
    throw new HttpsError("internal", "Unable to enable notifications. Try again later.");
  }
});

exports.unregisterFlareMapDevice = onCall(options, async request => {
  const token = validateToken(request.data?.token);
  try {
    const result = await admin.messaging().unsubscribeFromTopic(token, TOPIC);
    if (result.failureCount) throw new Error("Could not unsubscribe this token.");
    return { subscribed: false };
  } catch (error) {
    console.error("FCM topic unsubscribe failed", error);
    throw new HttpsError("internal", "Unable to disable notifications. Try again later.");
  }
});

exports.getFlareMapAdminStatus = onCall(options, async request => ({
  admin: isAdmin(request)
}));

// Server-side authorization is mandatory. Never put FCM server credentials in the browser.
exports.sendFlareMapAlarm = onCall(options, async request => {
  requireAdmin(request);
  const title = request.data?.title;
  const body = request.data?.body;
  if (typeof title !== "string" || !title.trim() || title.trim().length > 65 ||
      typeof body !== "string" || !body.trim() || body.trim().length > 220) {
    throw new HttpsError("invalid-argument", "Enter a title (1–65 chars) and message (1–220 chars).");
  }
  try {
    const messageId = await admin.messaging().send({
      topic: TOPIC,
      // Data-only: the browser service worker handles exactly one background notification.
      data: {
        title: title.trim(),
        body: body.trim(),
        type: "admin_alert"
      },
      webpush: {
        headers: { Urgency: "high", TTL: "3600" }
      }
    });
    console.log("FlareMap administrator broadcast accepted", { uid: request.auth.uid, messageId });
    return { success: true, messageId };
  } catch (error) {
    console.error("FCM broadcast failure", error);
    throw new HttpsError("internal", "Firebase could not accept the broadcast.");
  }
});
