# FlareMap — GitHub Pages website

FlareMap is a classroom demonstration of a room-monitoring dashboard. **DHT22, MQ-5 and MQ-7 readings are simulated** in the browser. The normal dashboard is public. The administrator panel is hidden and can be opened by clicking the flame logo five times within four seconds, or by pressing Ctrl+Shift+A (Cmd+Shift+A on Mac).

## Publish the website using GitHub Pages (no server needed for demo readings)

1. Create a new GitHub repository, for example `flaremap`.
2. Upload **all files and folders from this folder**, keeping the `docs` folder intact, and commit them on branch `main`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source: Deploy from a branch**, **Branch: main**, **Folder: /docs**, then **Save**.
5. GitHub will publish at a URL similar to `https://YOUR_USERNAME.github.io/flaremap/` (use the exact URL from your Pages settings).

All website files (HTML, CSS, JavaScript, service worker, manifest, icons) live under `docs/`. Relative paths are used so GitHub Pages project sites work under `/flaremap/` as well as other repository names. Do not upload only `index.html`; it needs the other files and both icons.

The sensor demo and hidden login interface run on GitHub Pages without deploying any Firebase Functions. You can **show** the admin panel, but actual remote notification broadcasts will not succeed until the Firebase backend is configured.

## Optional: make notifications work across phones and laptops

GitHub Pages cannot execute server-side JavaScript. To actually broadcast notifications from the hidden admin panel, keep the static website hosted on GitHub Pages and deploy the separately provided `functions/` backend to the **existing Firebase project**.

Prerequisites:
- Firebase Cloud Messaging and Firebase Authentication configured in project `flaremap-a1849`.
- Email/password sign-in enabled; create and verify your administrator's account.
- In Firebase Cloud Messaging, verify the public VAPID key in `docs/app.js` matches the project's Web Push key pair.
- Create `functions/.env` from `functions/.env.example`, replacing the example email with the administrator's actual address. **Do not commit `.env` to GitHub.**
- On Firebase Authentication authorized domains, add your exact GitHub Pages hosting domain (for example `YOUR_USERNAME.github.io`) if required for your chosen sign-in flow.
- Enable Firebase Functions and any billing prerequisites required by Firebase.

Commands from the repository root:

```bash
npm install -g firebase-tools
firebase login
cd functions
npm install
cd ..
firebase deploy --only functions --project flaremap-a1849
```

Important: You are **not** deploying the website with Firebase Hosting. The live frontend URL stays on GitHub Pages. The Firebase SDK in `docs/app.js` connects to cloud functions in region `asia-southeast1`.

### Testing notifications

- On the phone or laptop, open the HTTPS GitHub Pages URL and press **Enable notifications**; approve the browser request.
- On iPhone/iPad (iOS 16.4+), install the site to Home Screen first, launch it from Home Screen, then enable notifications.
- On the administrator's browser, click the fire logo five times within four seconds; sign in with the verified admin account and send a notification.
- Background notifications depend on device OS, browser and user settings. Firebase accepting a broadcast is not proof every device received it.

## File map

```
flaremap/
├── docs/                       # Public GitHub Pages web app
│   ├── index.html              # Dashboard + hidden admin modal
│   ├── style.css               # Responsive design
│   ├── app.js                  # Demo readings + admin controls + push opt-in
│   ├── firebase-messaging-sw.js# Service worker + background push
│   ├── manifest.json           # PWA metadata
│   ├── .nojekyll
│   └── icons/
│       ├── icon-192.png
│       └── icon-512.png
├── functions/                  # OPTIONAL Firebase backend, not hosted by GitHub
│   ├── index.js                # Admin checks, device registration, broadcasts
│   ├── package.json
│   └── .env.example
├── firebase.json               # Functions-only deployment
├── .firebaserc                 # Your existing Firebase project ID
├── .gitignore                  # Prevent accidental secret commits
└── README.md
```

## Code tour for demonstrating changes

1. `docs/index.html`: sensor cards, notification opt-in button, admin modal marked `hidden`.
2. `docs/style.css`: responsive card grid and admin-overlay styles.
3. `docs/app.js`: `updateDashboard` simulates values and updates charts.
4. `docs/app.js`: `secretAdminTrigger` counts clicks and opens the hidden login panel.
5. `docs/app.js`: `enablePushButton` requests notification permission and subscribes.
6. `docs/app.js`: `broadcastAlarmButton` calls `sendFlareMapAlarm`.
7. `functions/index.js`: `requireAdmin()` checks the verified Firebase account before broadcasting.

## Safety and security

This is not a real fire/gas/carbon-monoxide detector; the sensor data is artificial. A hidden button is only a user-interface convenience, not security; admin authorization must be verified by the Firebase backend. Firebase web config and VAPID **public** key may appear in client JavaScript; never put service-account secrets or private keys in the GitHub repo.
