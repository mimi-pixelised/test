# Key code changes to show in VS Code

These are the main new/rewritten areas relative to the original FlareMap upload.

### `docs/index.html`
- Public dashboard with four sensor cards: DHT22 temperature/humidity, MQ-5 gas, MQ-7 carbon monoxide (demo/raw values only).
- Hidden administrator dialog: `<div id="adminOverlay" ... hidden>`.
- Public notification opt-in button: `<button id="enablePushButton" ...>`.

### `docs/style.css`
- New responsive card/dashboard layout, chart tabs, notification panel and admin overlay.

### `docs/app.js`
- Uses `sensors` objects with small, continuous random changes (instead of a fresh random value every 5 seconds).
- Uses `renderSpark`, `renderChart` and `updateDashboard` for charting.
- `secretAdminTrigger` counts 5 logo clicks within 4 seconds, then runs `openAdminPanel()`; keyboard shortcut also added.
- `subscribeToAlerts` registers an opted-in browser FCM token; visitors need not sign in as admin.
- `broadcastAlarmButton` calls `sendFlareMapAlarm` with a message written by the admin.

### `docs/firebase-messaging-sw.js`
- Caches the app shell for offline demo UI.
- Receives Firebase background push events and displays a notification.

### `functions/index.js`
- Allows registration/unregistration of notification tokens.
- Validates admin account on the server before broadcasting to the FCM subscriber topic.

### GitHub Pages hosting change
- Moved all website files from `public/` to `docs/`.
- Updated `firebase.json` to deploy **Functions only**; GitHub Pages, not Firebase Hosting, serves the UI.
- Added `docs/.nojekyll`, `.gitignore`, and this GitHub-specific README.
