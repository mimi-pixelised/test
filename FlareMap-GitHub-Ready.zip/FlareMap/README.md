# FlareMap

Room-monitoring dashboard with simulated temperature, humidity, gas and carbon monoxide readings.

## Publish on GitHub Pages

1. Extract this ZIP.
2. Upload the contents of the `FlareMap` folder to your GitHub repository. Keep the `docs` folder and its contents together.
3. In the repository, open **Settings → Pages**.
4. Set **Source** to **Deploy from a branch**, select **main**, select **/docs**, and save.
5. Open the website URL shown by GitHub Pages when deployment finishes.

No build command is needed. The website files are in `docs/`. Relative asset paths support repository URLs as well as custom domains.

## Files

- `docs/index.html`: dashboard and administrator panel.
- `docs/style.css`: desktop and mobile layouts.
- `docs/app.js`: simulated readings, charts, sign-in and notification controls.
- `docs/assets/room.svg`: building illustration.
- `docs/icons/`: house icons for the browser and installed app.
- `docs/manifest.json`: installable app settings.
- `docs/firebase-messaging-sw.js`: offline files and background notifications.
- `functions/`: optional Firebase backend for administrator verification and notification broadcasts.

## Administrator account and notifications

The dashboard works immediately. Administrator sign-in and remote broadcasts require Firebase setup. There is no default administrator email or password.

The supplied frontend is configured for Firebase project `flaremap-a1849`. To use it:

1. Enable Email/Password in Firebase Authentication and create your administrator account with a password you choose.
2. Copy `functions/.env.example` to `functions/.env` and replace the example email with that account's email. Do not upload the `.env` file to GitHub.
3. Configure Cloud Messaging and check that the public Web Push VAPID key in `docs/app.js` belongs to your project.
4. Deploy the functions below. Firebase Functions may require billing to be enabled.
5. On the website, click the house logo five times within four seconds, or press Ctrl+Shift+A (Cmd+Shift+A on Mac), to open the admin panel. Sign in and use **Resend email verification** if the account is not verified. Open the verification link, then sign in again.
6. Enable notifications on each device that should receive messages. On iPhone, first add the website to the Home Screen and open it from there.

Add your GitHub Pages hostname to Firebase Authentication's authorized domains when required by your sign-in setup.

### Deploy the optional Firebase backend

Run these from the `FlareMap` folder with Node.js and the Firebase CLI installed:

```bash
firebase login
npm --prefix functions install
firebase deploy --only functions --project flaremap-a1849
```

GitHub Pages serves the frontend; Firebase runs the notification backend separately. Deploying to GitHub Pages does not create an administrator account or deploy the Firebase functions.

If using another Firebase project, update `.firebaserc` and the public Firebase configuration in both `docs/app.js` and `docs/firebase-messaging-sw.js`, and replace the public VAPID key in `docs/app.js`.

## Demo data

Readings refresh every five seconds and are simulated in the browser. The MQ-5 and MQ-7 figures are raw, uncalibrated sample values. No physical sensor connection is included.
