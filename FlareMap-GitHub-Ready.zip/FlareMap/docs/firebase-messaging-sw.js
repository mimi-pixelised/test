/* FlareMap unified service worker: offline app shell + Firebase background messaging. */
const CACHE_NAME = "flaremap-shell-v8";
const ASSETS = ["./", "./index.html", "./style.css", "./app.js", "./manifest.json", "./assets/room.svg", "./icons/house.svg", "./icons/icon-192.png", "./icons/icon-512.png"];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil(Promise.all([
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))),
    self.clients.claim()
  ]));
});
self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith(fetch(request).then(response => {
    if (response.ok) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(() => {});
    }
    return response;
  }).catch(async () => (await caches.match(request)) || (request.mode === "navigate" ? caches.match("./index.html") : Response.error())));
});

importScripts("https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js");
firebase.initializeApp({
  apiKey: "AIzaSyANFcISiv0jZL7U4sefd5i0eIUqG7r7MDU",
  authDomain: "flaremap-a1849.firebaseapp.com",
  projectId: "flaremap-a1849",
  storageBucket: "flaremap-a1849.firebasestorage.app",
  messagingSenderId: "931766029438",
  appId: "1:931766029438:web:69557ac21ea3882c109c2f"
});
const messaging = firebase.messaging();
messaging.onBackgroundMessage(payload => {
  // Backend sends data-only messages to avoid duplicate notifications.
  const title = payload.data?.title || "FlareMap notice";
  return self.registration.showNotification(title, {
    body: payload.data?.body || "A new FlareMap alert arrived.",
    icon: "./icons/icon-192.png",
    badge: "./icons/icon-192.png",
    tag: `flaremap-${Date.now()}`,
    data: { url: new URL("./", self.registration.scope).href }
  });
});
self.addEventListener("notificationclick", event => {
  event.notification.close();
  event.waitUntil((async () => {
    const url = new URL("./", self.registration.scope).href;
    const windows = await clients.matchAll({ type: "window", includeUncontrolled: true });
    const existing = windows.find(client => client.url.startsWith(url));
    if (existing) return existing.focus();
    return clients.openWindow(url);
  })());
});
