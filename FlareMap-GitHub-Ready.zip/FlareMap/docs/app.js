/* FlareMap: simple public dashboard, hidden verified-admin broadcast, demo sensor data. */
"use strict";

const firebaseConfig = {
  apiKey: "AIzaSyANFcISiv0jZL7U4sefd5i0eIUqG7r7MDU",
  authDomain: "flaremap-a1849.firebaseapp.com",
  projectId: "flaremap-a1849",
  storageBucket: "flaremap-a1849.firebasestorage.app",
  messagingSenderId: "931766029438",
  appId: "1:931766029438:web:69557ac21ea3882c109c2f"
};
const VAPID_KEY = "BKxUMBei3vHExEPRaHhDrw0g0NJaO7r21gA5r0sG3fP-Y-qTgg9_t1_7ZMDKyg4Lwp0vHeNdK8deiPqvAEYk6Ds";
const $ = id => document.getElementById(id);
const hasFirebase = typeof firebase !== "undefined";
let auth = null, functions = null, messaging = null, pushWorker = null;
let deferredInstallPrompt = null, toastTimer = null;
const STORAGE_KEY = "flaremap-notifications-enabled";
// Secret admin entry: click/tap the house logo five times within four seconds.
// Ctrl+Shift+A (or Cmd+Shift+A) also opens it on desktop.
// The modal is hidden for ordinary visitors; Cloud Functions enforce real admin access.
let logoClickCount = 0;
let firstLogoClickAt = 0;
let returnFocusTo = null;
function openAdminPanel() {
  const overlay = $("adminOverlay");
  if (!overlay.hidden) return;
  returnFocusTo = document.activeElement;
  overlay.hidden = false;
  document.body.classList.add("modal-open");
  ($("adminControls").hidden ? $("adminEmail") : $("broadcastAlarmButton")).focus();
}
function closeAdminPanel() {
  $("adminOverlay").hidden = true;
  document.body.classList.remove("modal-open");
  if (returnFocusTo?.isConnected) returnFocusTo.focus();
}
$("secretAdminTrigger").addEventListener("click", () => {
  const now = Date.now();
  if (now - firstLogoClickAt > 4000) { logoClickCount = 0; firstLogoClickAt = now; }
  if (++logoClickCount >= 5) { logoClickCount = 0; openAdminPanel(); }
});
document.addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "a") {
    e.preventDefault(); openAdminPanel();
  }
  if (e.key === "Escape" && !$("adminOverlay").hidden) closeAdminPanel();
});
$("adminCloseButton").addEventListener("click", closeAdminPanel);
$("adminOverlay").addEventListener("click", e => {
  if (e.target === $("adminOverlay")) closeAdminPanel();
});

let subscribed = false;
let activeSensor = "temperature";

// The values and trends below are completely simulated. NOT safety measurements.
const sensors = {
  temperature: { name: "Temperature", unit: "°C", value: 26.3, min: 23, max: 31, jitter: 0.35, decimal: 1, color: "#82c6d6" },
  humidity: { name: "Humidity", unit: "%", value: 57, min: 42, max: 70, jitter: 1.1, decimal: 0, color: "#92d7cd" },
  mq5: { name: "MQ-5", unit: "raw", value: 145, min: 80, max: 220, jitter: 8.5, decimal: 0, color: "#dca453" },
  mq7: { name: "MQ-7", unit: "raw", value: 124, min: 60, max: 200, jitter: 7.5, decimal: 0, color: "#ab91df" }
};
for (const sensor of Object.values(sensors)) {
  sensor.history = [];
  let value = sensor.value;
  for (let i = 0; i < 22; i++) {
    value = Math.max(sensor.min, Math.min(sensor.max, value + (Math.random() - 0.5) * sensor.jitter * 2));
    sensor.history.push(value);
  }
  sensor.value = value;
}
const format = sensor => sensor.value.toFixed(sensor.decimal);
const makeSvg = (tag, attrs = {}) => {
  const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, String(value));
  return el;
};
function pointsFor(data, width, height, margin = 4) {
  const lo = Math.min(...data), hi = Math.max(...data);
  const range = Math.max(hi - lo, 0.001);
  return data.map((v, i) => [margin + i * (width - 2 * margin) / Math.max(data.length - 1, 1), height - margin - (v - lo) / range * (height - 2 * margin)]);
}
function linePath(points) {
  return points.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`).join(" ");
}
function renderSpark(key) {
  const svg = $(`spark-${key}`), sensor = sensors[key];
  const points = pointsFor(sensor.history.slice(-15), 112, 38, 3);
  svg.replaceChildren(makeSvg("polyline", {
    points: points.map(p => p.join(",")).join(" "), fill: "none", stroke: "currentColor",
    "stroke-width": 2.7, "stroke-linecap": "round", "stroke-linejoin": "round"
  }));
}
function renderChart() {
  const sensor = sensors[activeSensor];
  $("chartLabel").textContent = sensor.name;
  $("chartCurrent").textContent = format(sensor);
  $("chartUnit").textContent = sensor.unit;
  const points = pointsFor(sensor.history, 720, 200, 22);
  const path = linePath(points);
  const hi = Math.max(...sensor.history), lo = Math.min(...sensor.history);
  $("chartHigh").textContent = hi.toFixed(sensor.decimal);
  $("chartMid").textContent = ((hi + lo) / 2).toFixed(sensor.decimal);
  $("chartLow").textContent = lo.toFixed(sensor.decimal);
  $("chartLine").setAttribute("d", path);
  $("chartLine").setAttribute("stroke", sensor.color);
  $("chartArea").setAttribute("d", `${path} L${points.at(-1)[0].toFixed(1)} 207 L${points[0][0].toFixed(1)} 207 Z`);
  $("chartDot").setAttribute("cx", points.at(-1)[0]);
  $("chartDot").setAttribute("cy", points.at(-1)[1]);
  $("chartDot").setAttribute("fill", sensor.color);
  const grid = $("chartGrid");
  grid.replaceChildren(...[22, 68, 114, 160, 207].map(y => makeSvg("line", {
    x1: 0, y1: y, x2: 720, y2: y, stroke: "#e8edf4", "stroke-width": 1, "stroke-dasharray": "4 6"
  })));
  const gradient = $("chartFill");
  gradient.children[0].setAttribute("stop-color", sensor.color);
  gradient.children[1].setAttribute("stop-color", sensor.color);
  $("trendChart").setAttribute("aria-label", `Simulated ${sensor.name} trend`);
}
function updateDashboard() {
  for (const [key, sensor] of Object.entries(sensors)) {
    const target = (sensor.min + sensor.max) / 2;
    const drift = (target - sensor.value) * 0.025;
    sensor.value = Math.max(sensor.min, Math.min(sensor.max, sensor.value + drift + (Math.random() - 0.5) * sensor.jitter * 2));
    sensor.history.push(sensor.value);
    if (sensor.history.length > 22) sensor.history.shift();
    $(key).textContent = format(sensor);
    renderSpark(key);
  }
  $("lastUpdated").textContent = `Demo refreshed ${new Date().toLocaleTimeString([], {hour: "2-digit", minute: "2-digit", second: "2-digit"})}`;
  renderChart();
}
for (const tab of document.querySelectorAll(".chart-tab")) {
  tab.addEventListener("click", () => {
    activeSensor = tab.dataset.sensor;
    for (const other of document.querySelectorAll(".chart-tab")) {
      const active = other === tab;
      other.classList.toggle("active", active);
      other.setAttribute("aria-pressed", String(active));
    }
    renderChart();
  });
}
updateDashboard();
setInterval(updateDashboard, 5000);

// Show app install prompts where supported, with a manual fallback for iOS.
window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredInstallPrompt = event;
});
window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  toast("FlareMap installed. Open it from your home screen and enable notifications.");
});
function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, 6000);
}
$("installAppButton").addEventListener("click", async () => {
  if (window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true) {
    toast("FlareMap is already running as an installed app.");
    return;
  }
  if (deferredInstallPrompt) {
    const prompt = deferredInstallPrompt;
    deferredInstallPrompt = null;
    await prompt.prompt();
    return;
  }
  const isAppleMobile = /iPad|iPhone|iPod/.test(navigator.userAgent);
  toast(isAppleMobile
    ? "On iPhone: open this page in Safari, tap Share, then Add to Home Screen. Open the installed app to enable notifications."
    : "Use your browser menu and choose Install app or Add to Home screen. HTTPS and PWA support are required.");
});

function setMessage(id, message, status = "") {
  const target = $(id);
  target.textContent = message;
  target.className = `inline-message ${status}`;
}
function getSavedOptIn() {
  try { return localStorage.getItem(STORAGE_KEY) === "yes"; } catch { return false; }
}
function setSavedOptIn(enabled) {
  try { enabled ? localStorage.setItem(STORAGE_KEY, "yes") : localStorage.removeItem(STORAGE_KEY); } catch { /* private browsing */ }
}
function setPushState(enabled) {
  subscribed = enabled;
  $("pushStatus").textContent = enabled ? "Notifications enabled on this device" : "Notifications are off";
  $("enablePushButton").textContent = enabled ? "Turn off notifications" : "Enable notifications";
  $("pushStateDot").parentElement.classList.toggle("enabled", enabled);
}
async function getMessagingInstance() {
  if (!hasFirebase || !functions) throw new Error("Firebase is unavailable. Connect to the internet and reload.");
  if (!window.isSecureContext || !("serviceWorker" in navigator) || !("Notification" in window)) {
    throw new Error("Push requires a supported browser and HTTPS (or localhost).");
  }
  if (!(await firebase.messaging.isSupported())) throw new Error("This browser does not support Firebase push messaging.");
  if (!messaging) messaging = firebase.messaging();
  if (!pushWorker) pushWorker = await navigator.serviceWorker.register("./firebase-messaging-sw.js", { scope: "./" });
  return messaging;
}
async function subscribeToAlerts(requestPermission) {
  // Request permission directly in the button gesture before other awaits (iOS requirement).
  if (requestPermission) {
    if (!("Notification" in window)) throw new Error("Notifications are not supported in this browser.");
    const permission = await Notification.requestPermission();
    if (permission !== "granted") throw new Error("Notification permission was not granted. Check your browser settings.");
  }
  if (Notification.permission !== "granted") throw new Error("Notifications are not permitted on this device.");
  const instance = await getMessagingInstance();
  const token = await instance.getToken({ vapidKey: VAPID_KEY, serviceWorkerRegistration: pushWorker });
  if (!token) throw new Error("Firebase could not provide a push token.");
  await functions.httpsCallable("registerFlareMapDevice")({ token });
  setSavedOptIn(true);
  setPushState(true);
  setMessage("pushMessage", "Subscribed. This device can now receive administrator broadcasts.", "success");
  // Foreground notifications are shown in the dashboard. Background notifications come from the SW.
  if (!window.flaremapForegroundListener) {
    window.flaremapForegroundListener = true;
    instance.onMessage(payload => {
      const title = String(payload.data?.title || "FlareMap notice");
      const body = String(payload.data?.body || "A new announcement arrived.");
      $("notificationActivity").replaceChildren();
      const dot = document.createElement("span"); dot.className = "activity-dot";
      const copy = document.createElement("span"); copy.textContent = `${title}: ${body}`;
      $("notificationActivity").append(dot, copy);
      toast(`${title} — ${body}`);
    });
  }
}
async function unsubscribeFromAlerts() {
  const instance = await getMessagingInstance();
  const token = await instance.getToken({ vapidKey: VAPID_KEY, serviceWorkerRegistration: pushWorker });
  if (token) await functions.httpsCallable("unregisterFlareMapDevice")({ token });
  setSavedOptIn(false);
  setPushState(false);
  setMessage("pushMessage", "Unsubscribed. Re-enable notifications whenever you like.", "success");
}
$("enablePushButton").addEventListener("click", async () => {
  const button = $("enablePushButton");
  button.disabled = true;
  setMessage("pushMessage", "");
  try {
    if (subscribed) await unsubscribeFromAlerts();
    else await subscribeToAlerts(true);
  } catch (error) {
    console.error("Notification error", error);
    setMessage("pushMessage", error.message || "Could not update notification subscription.", "error");
  } finally { button.disabled = false; }
});

// Firebase Authentication is only for the administrator. Public push opt-in needs no login.
if (hasFirebase) {
  try {
    firebase.initializeApp(firebaseConfig);
    auth = firebase.auth();
    functions = firebase.app().functions("asia-southeast1");
  } catch (error) {
    console.error("Firebase setup failed", error);
    setMessage("pushMessage", "Could not initialize Firebase. The sensor demo still works.", "error");
  }
} else {
  setMessage("pushMessage", "Firebase did not load. The sensor demo works offline; push alerts require a connection.", "error");
}

function updateAdminUI(isAdmin, user) {
  $("adminLoginForm").hidden = isAdmin;
  $("adminControls").hidden = !isAdmin;
  if (isAdmin && user) $("adminIdentity").textContent = user.email || "Verified administrator";
}
if (auth && functions) {
  auth.onAuthStateChanged(async user => {
    updateAdminUI(false, null);
    if (!user) return;
    try {
      await user.getIdToken(true);
      const response = await functions.httpsCallable("getFlareMapAdminStatus")();
      if (response.data?.admin === true) {
        updateAdminUI(true, user);
        setMessage("adminMessage", "Administrator access verified.", "success");
      } else if (!user.emailVerified) {
        setMessage("adminMessage", "Your email is not verified. Use the verification link sent to your inbox.", "error");
      } else {
        setMessage("adminMessage", "This account is not authorized as a FlareMap administrator.", "error");
      }
    } catch (error) {
      setMessage("adminMessage", `Could not verify administrator access: ${error.message}`, "error");
    }
  });
}
$("adminLoginForm").addEventListener("submit", async event => {
  event.preventDefault();
  const button = $("adminLoginButton"); button.disabled = true;
  setMessage("adminMessage", "Signing in...");
  try {
    if (!auth) throw new Error("Firebase Authentication unavailable.");
    const email = $("adminEmail").value.trim(), password = $("adminPassword").value;
    if (!email || !password) throw new Error("Enter your administrator email and password.");
    const credentials = await auth.signInWithEmailAndPassword(email, password);
    await credentials.user.reload();
    await credentials.user.getIdToken(true);
    if (!credentials.user.emailVerified) {
      setMessage("adminMessage", "Your email is not verified. Check your email or use Resend verification.", "error");
      return;
    }
    const result = await functions.httpsCallable("getFlareMapAdminStatus")();
    if (!result.data?.admin) {
      await auth.signOut();
      throw new Error("This account is not on the administrator allowlist.");
    }
    updateAdminUI(true, credentials.user);
    setMessage("adminMessage", "Administrator access verified.", "success");
    $("adminPassword").value = "";
  } catch (error) {
    setMessage("adminMessage", `Sign in failed: ${error.message}`, "error");
  } finally { button.disabled = false; }
});
$("resendVerificationButton").addEventListener("click", async () => {
  try {
    if (!auth?.currentUser) throw new Error("Sign in with your account first, then request a verification link.");
    await auth.currentUser.sendEmailVerification();
    setMessage("adminMessage", "Verification email requested. Check your inbox and spam folder.", "success");
  } catch (error) { setMessage("adminMessage", error.message, "error"); }
});
$("adminLogoutButton").addEventListener("click", async () => {
  if (!auth) return;
  try {
    await auth.signOut();
    updateAdminUI(false, null);
    setMessage("adminMessage", "Signed out.", "success");
  } catch (error) { setMessage("adminMessage", error.message, "error"); }
});
$("broadcastAlarmButton").addEventListener("click", async () => {
  const title = $("alertTitle").value.trim(), body = $("alertBody").value.trim();
  if (!title || !body) { setMessage("adminMessage", "Add a notification title and message.", "error"); return; }
  if (!window.confirm(`Broadcast this message to ALL opted-in FlareMap devices?\n\n${title}\n${body}`)) return;
  const button = $("broadcastAlarmButton"); button.disabled = true;
  setMessage("adminMessage", "Submitting your broadcast...");
  try {
    if (!auth?.currentUser) throw new Error("Sign in as an administrator first.");
    await auth.currentUser.getIdToken(true);
    const response = await functions.httpsCallable("sendFlareMapAlarm")({ title, body });
    setMessage("adminMessage", `Broadcast accepted by Firebase Cloud Messaging. Message ID: ${response.data.messageId}`, "success");
  } catch (error) {
    setMessage("adminMessage", `Broadcast failed: ${error.message}`, "error");
  } finally { button.disabled = false; }
});

// One service worker handles PWA offline shell and push messages (avoid conflicting registrations).
window.addEventListener("load", async () => {
  if ("serviceWorker" in navigator && window.isSecureContext) {
    try { pushWorker = await navigator.serviceWorker.register("./firebase-messaging-sw.js", {scope: "./"}); }
    catch (error) { console.warn("PWA service worker registration failed", error); }
  }
  // Re-register previously opted-in installations to refresh FCM tokens when possible.
  if (getSavedOptIn()) {
    if (typeof Notification === "undefined" || Notification.permission !== "granted") {
      setSavedOptIn(false); setPushState(false);
    } else {
      try { await subscribeToAlerts(false); }
      catch (error) { setMessage("pushMessage", `Could not renew notifications: ${error.message}`, "error"); }
    }
  }
});
